<?php
/***************************************************************************
*                                index.php
*                            -----------------------
*   begin                : Friday, March 20, 2015
*   copyright            : (C) 2015 Atari Legend
*   email                : martens_maarten@hotmail.com
*   actual update        : Creation of file
*
*   Id: index.php,v 0.1 2015/03/20 21:06 ST Graveyard
*
***************************************************************************/

//****************************************************************************************
// This file is only used to start up the actual website
//**************************************************************************************** 

header("Location: front/front.php?action=first_time");
?>




